<?php
$conn->close();
echo "end of php file";
?>